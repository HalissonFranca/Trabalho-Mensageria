package com.exemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prova1MensageriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
